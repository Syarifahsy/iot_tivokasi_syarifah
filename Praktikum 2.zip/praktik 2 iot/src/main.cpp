#include <Arduino.h>

int tombol1 = 34;
int tombol2 = 35;
int tombol3 = 32;

int ledm = 19;
int ledk = 18;
int ledh = 17;

bool tombol1Pressed = false;
bool tombol2Pressed = false;
bool tombol3Pressed = false;

void setup() {
    Serial.begin(115200);
    Serial.println("ESP32 Wokwi Simulation Start");

    pinMode(tombol1, INPUT_PULLUP);
    pinMode(tombol2, INPUT_PULLUP);
    pinMode(tombol3, INPUT_PULLUP);

    pinMode(ledm, OUTPUT);
    pinMode(ledk, OUTPUT);
    pinMode(ledh, OUTPUT);
}

void loop() {
    if (digitalRead(tombol1) == LOW && !tombol1Pressed) {
        tombol1Pressed = true;
        Serial.println("Tombol 1 ditekan: Lampu merah berkedip 5x");
        for (int i = 0; i < 5; i++) {
            digitalWrite(ledm, HIGH);
            delay(500);
            digitalWrite(ledm, LOW);
            delay(500);
        }
    } else if (digitalRead(tombol1) == HIGH) {
        tombol1Pressed = false;
    }

    if (digitalRead(tombol2) == LOW && !tombol2Pressed) {
        tombol2Pressed = true;
        Serial.println("Tombol 2 ditekan: Lampu merah & hijau berkedip bergantian");
        for (int i = 0; i < 5; i++) {
            digitalWrite(ledm, HIGH);
            digitalWrite(ledh, LOW);
            delay(500);
            digitalWrite(ledm, LOW);
            digitalWrite(ledh, HIGH);
            delay(500);
        }
        digitalWrite(ledh, LOW);
    } else if (digitalRead(tombol2) == HIGH) {
        tombol2Pressed = false;
    }

    if (digitalRead(tombol3) == LOW && !tombol3Pressed) {
        tombol3Pressed = true;
        Serial.println("Tombol 3 ditekan: Lampu merah, kuning, hijau berkedip bergantian");
        for (int i = 0; i < 5; i++) {
            digitalWrite(ledm, HIGH);
            delay(300);
            digitalWrite(ledm, LOW);
            digitalWrite(ledk, HIGH);
            delay(300);
            digitalWrite(ledk, LOW);
            digitalWrite(ledh, HIGH);
            delay(300);
            digitalWrite(ledh, LOW);
        }
    } else if (digitalRead(tombol3) == HIGH) {
        tombol3Pressed = false;
    }
}